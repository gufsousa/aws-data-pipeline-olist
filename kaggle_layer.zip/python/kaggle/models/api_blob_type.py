class ApiBlobType(object):
  DATASET = "dataset"
  MODEL = "model"
  INBOX = "inbox"
